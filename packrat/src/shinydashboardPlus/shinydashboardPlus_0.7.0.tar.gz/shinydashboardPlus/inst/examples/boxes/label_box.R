label_box <- 'boxPlus(
  title = "Closable box, with label", 
  closable = TRUE, 
  width = NULL,
  enable_label = TRUE,
  label_text = 1,
  label_status = "danger",
  status = "warning", 
  solidHeader = FALSE, 
  collapsible = TRUE,
  p("Box Content")
)'