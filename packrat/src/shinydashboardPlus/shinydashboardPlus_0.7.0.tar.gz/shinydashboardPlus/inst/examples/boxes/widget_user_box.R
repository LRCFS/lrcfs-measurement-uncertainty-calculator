widget_user_box1 <- 'widgetUserBox(
  title = "Nadia Carmichael",
  subtitle = "lead Developer",
  width = 12,
  type = 2,
  src = "https://adminlte.io/themes/AdminLTE/dist/img/user7-128x128.jpg",
  color = "yellow",
  "Some text here!",
  footer = "The footer here!"
)'

widget_user_box2 <- 'widgetUserBox(
  title = "Alexander Pierce",
  subtitle = "Founder & CEO",
  type = NULL,
  width = 12,
  src = "https://adminlte.io/themes/AdminLTE/dist/img/user1-128x128.jpg",
  color = "aqua-active",
  closable = TRUE,
  "Some text here!",
  footer = "The footer here!"
)'


widget_user_box3 <- 'widgetUserBox(
  title = "Elizabeth Pierce",
  subtitle = "Web Designer",
  type = NULL,
  width = 12,
  src = "https://adminlte.io/themes/AdminLTE/dist/img/user3-128x128.jpg",
  background = TRUE,
  backgroundUrl = "https://images.pexels.com/photos/531880/pexels-photo-531880.jpeg?auto=compress&cs=tinysrgb&h=350",
  closable = TRUE,
  "Some text here!",
  footer = "The footer here!"
)'